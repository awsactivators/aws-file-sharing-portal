import json
from loguru import logger
from freemiumer.utils.config_loader import config
from freemiumer.utils.cli_processor import CLIProcessor
from freemiumer.llm_utils.llm_connector import LLMConnector

# TODO: how to save logs with lambda?
# Initialize logger
# logger.add("/tmp/file_upload.log", rotation="10 MB", level="DEBUG")

# Retrieve the default destination from the configuration
# This will be S3 bucket
DEFAULT_DESTINATION = config.get('file_paths')['default']


def lambda_handler(event, context):
    # Assuming the file_path is passed in the 'event' object
    file_path = event.get('file_path')
    if not file_path:
        return {
            'statusCode': 400,
            'body': json.dumps('No file_path provided')
        }

    logger.info(f"Lambda function started with file path: {file_path}")

    # Initialize the LLMConnector
    logger.info(f"Initializing LLMConnector with engine: {config.get('llm_config')['engine']}")
    llm_connector = LLMConnector(config.get('llm_config')['api_key'])

    # Initialize the CLIProcessor
    logger.info(f"Initializing CLIProcessor with default destination: {DEFAULT_DESTINATION}")
    cli_processor = CLIProcessor(DEFAULT_DESTINATION, llm_connector)

    try:
        # Process the file path
        logger.info(f"Processing file at path: {file_path}")
        cli_processor.read_file_path(file_path)

        # Get recommendations
        logger.info(f"Retrieving recommendations for the processed file")
        cli_processor.get_recommendations()

        logger.info("Tuning recommendations based on the retrieved customer data.")
        cli_processor.process_recommendations()

        cli_processor.run_preprocessing()

        logger.info("Lambda processing complete.")

        return {
            'statusCode': 200,
            'body': json.dumps('Processing complete')
        }
    except Exception as e:
        logger.error(f"An error occurred during Lambda processing: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"An error occurred: {str(e)}")
        }
