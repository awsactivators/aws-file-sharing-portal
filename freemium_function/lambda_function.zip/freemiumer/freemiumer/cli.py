import click
from loguru import logger
from freemiumer.utils.config_loader import config
from freemiumer.utils.cli_processor import CLIProcessor
from freemiumer.llm_utils.llm_connector import LLMConnector

# Retrieve the default destination from the configuration
DEFAULT_DESTINATION = config.get('file_paths')['default']

# Configure the logger
logger.add("file_upload.log", rotation="10 MB", level="DEBUG")


@click.command()
@click.argument('file_path', type=str)
def main(file_path):
    logger.info(f"CLI started with file path: {file_path}")

    # Initialize the LLMConnector
    logger.info(f"Initializing LLMConnector with engine: {config.get('llm_config')['engine']}")
    llm_connector = LLMConnector(config.get('llm_config')['api_key'])

    # Initialize the CLIProcessor
    logger.info(f"Initializing CLIProcessor with default destination: {DEFAULT_DESTINATION}")
    cli_processor = CLIProcessor(DEFAULT_DESTINATION, llm_connector, file_path)

    # Process the file path
    logger.info(f"Processing file at path: {file_path}")
    cli_processor.read_file_path(file_path)

    # Get recommendations
    logger.info(f"Retrieving recommendations for the processed file")
    cli_processor.get_recommendations()

    logger.info("Tuning recommendations based on the retrieved customer data.")
    cli_processor.process_recommendations()

    cli_processor.run_preprocessing()

    logger.info("CLI processing complete.")


if __name__ == "__main__":
    logger.info("Starting the file processing CLI application")
    try:
        main()
    except Exception as e:
        logger.error(f"An error occurred during CLI processing: {e}")
    finally:
        logger.info("File processing CLI application terminated")

