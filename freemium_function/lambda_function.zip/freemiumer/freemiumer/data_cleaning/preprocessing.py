# Contains the mapping logic between LLM recommendations and functions in Retina


from loguru import logger
from retina.preprocess.deduplicate import KeepLatest, RetinaDeduplicator

from freemiumer.data_cleaning.utils import normalize_subset_columns, convert_to_boolean


def action_remove_duplicates(df, recommendation):
    """ Execute preprocessing functions on the given dataframe """
    try:
        logger.info("Starting deduplication process.")

        # Normalize the format of subset_columns using the separate function
        try:
            subset_columns = normalize_subset_columns(recommendation.get('subset_columns', []))
        except (ValueError, TypeError) as e:
            logger.error(f"Error in subset_columns format: {e}")
            return None

        # Convert run_multiple_times to boolean if it's a string
        run_multiple_times = recommendation.get('run_multiple_times', False)
        try:
            run_multiple_times = convert_to_boolean(run_multiple_times)
        except (ValueError, TypeError) as e:
            logger.error(f"Error in converting run_multiple_times to boolean: {e}")
            return None

        # Check if multiple runs are required
        if run_multiple_times:
            logger.info("Multiple deduplication runs required with different subset columns.")

            # Process each combination of subset_columns
            for i, subset in enumerate(subset_columns):
                if isinstance(subset, list):  # Ensure it's a list of column names
                    logger.info(f"Processing deduplication run {i + 1} with subset columns: {subset}")
                    deduplicator = KeepLatest(
                        subset_columns=subset,
                        sort_column=recommendation.get('sort_column')
                    )
                    df = deduplicator.fit(df)
                    logger.info(f"Completed deduplication run {i + 1}.")

        else:
            logger.info(f"Single deduplication run with subset columns: {subset_columns}")
            deduplicator = KeepLatest(
                subset_columns=subset_columns[0],
                sort_column=recommendation.get('sort_column')
            )
            df = deduplicator.fit(df)
            logger.info("Completed single deduplication run.")

        logger.info("Deduplication process completed successfully.")
        return df

    except Exception as e:
        logger.error(f"Error applying deduplication: {e}")
        return None


def action_remove_missing_values(df, recommendation):
    raise NotImplementedError("The action_remove_missing_values function is not yet implemented.")


def action_normalize_data(df, recommendation):
    raise NotImplementedError("The action_normalize_data function is not yet implemented.")


def action_handle_outliers(df, recommendation):
    raise NotImplementedError("The action_handle_outliers function is not yet implemented.")
