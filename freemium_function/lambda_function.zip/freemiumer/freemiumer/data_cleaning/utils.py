import json
import re

import pandas as pd
from loguru import logger
import ast


def compare_dataframes(df1, df2):
    # Compare shapes
    logger.info("Comparing Dataframe Shapes:")
    logger.info(f"Shape of First Dataframe: {df1.shape}")
    logger.info(f"Shape of Second Dataframe: {df2.shape}")

    # Compare columns
    logger.info("Comparing Dataframe Columns:")
    common_columns = set(df1.columns).intersection(df2.columns)
    df1_only = set(df1.columns) - common_columns
    df2_only = set(df2.columns) - common_columns
    logger.info(f"Common Columns: {common_columns}")
    logger.info(f"Columns only in First Dataframe: {df1_only}")
    logger.info(f"Columns only in Second Dataframe: {df2_only}")

    # Compare row-wise data for common columns
    logger.info("Comparing Row-wise Data for Common Columns:")
    for column in common_columns:
        match = df1[column].equals(df2[column])
        if not match:
            logger.info(f"Column '{column}' differs.")
            # Displaying differences - can be customized further as needed
            comparison = pd.concat([df1[column], df2[column]], axis=1, keys=['First', 'Second'])
            difference = comparison[comparison['First'] != comparison['Second']].head()  # Display first few differences
            logger.info(f"Differences in Column '{column}':\n{difference}")
        else:
            logger.info(f"Column '{column}' matches.")


def convert_to_boolean(value):
    """ Convert a string representation of a boolean to a boolean, or return the value if it's already a boolean """
    logger.debug(f"Converting value to boolean: {value}")

    if isinstance(value, bool):
        # The value is already a boolean, return as is
        logger.debug("Value is already a boolean.")
        return value
    elif isinstance(value, str):
        # Convert string to corresponding boolean value
        lower_value = value.lower()
        if lower_value in ['true', 'yes', '1']:
            logger.debug("Converted string to True.")
            return True
        elif lower_value in ['false', 'no', '0']:
            logger.debug("Converted string to False.")
            return False
        else:
            logger.error(f"Invalid string format for boolean conversion: '{value}'")
            raise ValueError(f"Invalid string format for boolean conversion: '{value}'")
    else:
        logger.error(f"Expected a boolean or a string, got {type(value)}")
        raise TypeError(f"Expected a boolean or a string, got {type(value)}")


def normalize_subset_columns(subset_columns):
    """ Normalize the format of subset_columns to a list of lists """
    logger.debug(f"Normalizing subset_columns: {subset_columns}")

    try:
        if isinstance(subset_columns, str):
            # Safely evaluate the string to a Python object
            evaluated_columns = ast.literal_eval(subset_columns)
            logger.debug(f"Evaluated subset_columns: {evaluated_columns}")
            if not all(isinstance(elem, list) for elem in evaluated_columns):
                raise ValueError("The evaluated string is not a list of lists.")
        elif isinstance(subset_columns, list):
            if not subset_columns:  # Empty list
                raise ValueError("No subset columns provided.")
            if not all(isinstance(elem, list) for elem in subset_columns):
                raise ValueError("subset_columns is a list but not a list of lists.")
        else:
            raise TypeError("subset_columns must be a string or a list.")

        logger.info("Successfully normalized subset_columns.")
        return evaluated_columns if isinstance(subset_columns, str) else subset_columns

    except (ValueError, TypeError, SyntaxError) as e:
        logger.error(f"Error in normalizing subset_columns: {e}")
        raise


def fix_json_string(s, parameter):
    logger.debug(f"Initial string: {s}")

    # Remove leading and trailing newline and double quote characters
    s = s.strip('\n"')
    logger.debug("Stripped leading/trailing newlines and double quotes.")
    logger.debug(f"Modified string: {s}")

    # Replace single quotes with double quotes for JSON compatibility
    s = s.replace("'", '"')
    logger.debug("Replaced single quotes with double quotes.")
    logger.debug(f"Modified string: {s}")

    # Escape double quotes inside the 'recommendation' values
    def escape_quotes(match):
        # Extract the recommendation text
        text = match.group(1)
        # Escape double quotes and return the modified recommendation
        return f'"{parameter}": "' + text.replace('"', '\\"') + '"'

    s = re.sub(rf'"{parameter}": "(.*?)"(?=,?\s*"\w+":)', escape_quotes, s, flags=re.DOTALL)
    logger.debug("Escaped double quotes inside the parameter values.")
    logger.debug(f"Modified string: {s}")

    # Replace '"null"' with 'null'
    s = s.replace('"null"', 'null')
    logger.debug("Replaced '\"null\"' with 'null'.")
    logger.debug(f"Modified string: {s}")

    # Convert string to JSON
    try:
        json_object = json.loads(s)
        logger.debug(f"Converted string to JSON successfully: {json_object}")
        return json_object  # Return the dictionary directly
    except json.JSONDecodeError as e:
        logger.error(f"Error decoding JSON: {e}")
        logger.error("Ensure that max_tokens in llm_config is sufficiently large.")
        return None


# def fix_python_dict_string(s):
#     # for actions
#     # Remove leading and trailing newline and space characters
#     s = s.strip('\n ')
#
#     # Replace single quotes with double quotes for JSON compatibility
#     s = s.replace("'", '"')
#
#     # Replace 'None' with 'null'
#     s = s.replace('None', 'null')
#
#     # Convert the corrected string to JSON
#     try:
#         json_object = json.loads(s)
#         return json_object
#     except json.JSONDecodeError as e:
#         return f"Error decoding JSON: {e}"


def compare_dict_keys(dict1, dict2):
    # Convert the keys of the dictionaries to sets
    keys_dict1 = set(dict1.keys())
    keys_dict2 = set(dict2.keys())

    # Find common keys and keys unique to dict1
    common_keys = keys_dict1.intersection(keys_dict2)
    unique_to_dict1 = keys_dict1.difference(keys_dict2)

    # Convert the sets back to lists (optional, depending on your requirement)
    common_keys_list = list(common_keys)
    unique_to_dict1_list = list(unique_to_dict1)

    return common_keys_list, unique_to_dict1_list

# import ast
# import json
#
# from loguru import logger
#
#
# def string_to_dict(input_string):
#     try:
#         # Extracting the dictionary part from the string
#         dict_str = input_string[input_string.find('{'):input_string.rfind('}') + 1]
#         # Converting string to dictionary
#         return ast.literal_eval(dict_str)
#     except Exception as e:
#         logger.error(f"Error converting string to dictionary: {e}")
#         return None
#
#
# def string_to_nested_dict(input_string):
#     try:
#         # Replace single quotes with double quotes for JSON compatibility
#         json_compatible_str = input_string.replace("'", '"')
#
#         # Convert the string to a nested dictionary
#         return json.loads(json_compatible_str)
#     except json.JSONDecodeError as e:
#         logger.error(f"Error converting string to nested dictionary: {e}")
#         return None
#
