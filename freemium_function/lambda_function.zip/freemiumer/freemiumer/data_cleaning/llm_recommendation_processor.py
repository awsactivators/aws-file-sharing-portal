from typing import Optional

from loguru import logger
from freemiumer.utils.config_loader import config
import json
from freemiumer.data_cleaning.preprocessing import action_remove_duplicates, action_remove_missing_values, \
    action_normalize_data, action_handle_outliers
from freemiumer.data_cleaning.utils import fix_json_string
from freemiumer.llm_utils.preprocessing_prompts import PREPROCESSING_ACTION_PROMPTS
from freemiumer.llm_utils.llm_helpers import create_preprocessing_prompt, process_llm_response, create_action_prompt

# Map action names to their corresponding functions
# TODO this has to be kept in line with PREPROCESSING_ACTION_PROMPTS keys
action_functions = {
    "remove_duplicates": action_remove_duplicates,
    "remove_missing": action_remove_missing_values,
    "normalize": action_normalize_data,
    "handle_outliers": action_handle_outliers
}


def process_action_string(action, action_string) -> Optional[dict]:
    logger.debug(f"Processing action string: {action_string}")
    # recommendations_str = self.actions_raw.get(action_string)
    # TODO: at the moment only remove_duplicates is implemented
    if action == 'remove_duplicates':
        try:
            logger.debug("Attempting to fix json string for 'remove_duplicates' action.")
            recommendations_fixed = fix_json_string(action_string, "subset_columns")
            logger.info(f"'remove_duplicates' action processed successfully.")
            return recommendations_fixed
        except Exception as e:
            logger.exception(f"Error processing 'remove_duplicates' action: {e}")
            return None
    else:
        logger.warning(f"Action '{action}' is not implemented.")
        return None


class LLMRecommendationProcessor:
    def __init__(self, llm_connector, file_processor):
        # self.file_path = Path(file_path)
        self.actions_raw = None
        self.file_processor = file_processor
        self.llm_connector = llm_connector
        self.prompt_type = config.get('llm_config')['prompt_recommendation']
        self.recommendations = dict()
        self.recommendations_raw = list()
        self.action_types = PREPROCESSING_ACTION_PROMPTS
        self.actions = dict()

    def get_recommendations_generic(self, type_key, create_prompt_function) -> [str, None]:
        try:
            logger.info(f"Reading file for {type_key} recommendations.")
            df = self.file_processor.read_file(self.file_processor.new_file_path)
            logger.info(f"Dataframe read successfully. Size: {df.shape}")
            # TODO remove head() to read the whole file or how much LLM will read
            data_sample = df.head().to_string(index=False)
            prompt = create_prompt_function(data_sample, type_key)
            if prompt:
                logger.info(f"Prompt created successfully for {type_key}. Sending to LLM.")
                response = self.llm_connector.query(prompt)
                recommendations = process_llm_response(response)
                logger.info(f"Received recommendations for {type_key}.")
                logger.debug(f"Recommendations: {recommendations}")
                return recommendations
            else:
                logger.error(f"Failed to create prompt for {type_key} recommendations.")
                return None
        except Exception as e:
            logger.error(f"Error in getting recommendations for {type_key}: {e}")
            return None

    def fetch_cleaning_recommendations(self) -> [str, None]:
        logger.info("Requesting cleaning recommendations.")
        try:
            recommendations = self.get_recommendations_generic(self.prompt_type, create_preprocessing_prompt)
            if recommendations is not None:
                logger.info("Successfully received cleaning recommendations.")
            else:
                logger.warning("No cleaning recommendations received.")
            return recommendations
        except Exception as e:
            logger.exception(f"Error in getting cleaning recommendations: {e}")
            return None

    def get_action_recommendations(self, action_type) -> Optional[str]:
        # TODO: at the moment when we send prompt to LLM we send only the action type. We don't send the original
        #  recommendation. What would be good to investigate is if we get better results if we include the first
        #  recommendation to the prompt.
        logger.info(f"Requesting action recommendations for '{action_type}'.")

        # Check if the recommendations is NotImplemented, if so don't send a request to LLM
        if self.action_types[action_type] == 'NotImplemented':
            logger.warning(f"Action recommendations for '{action_type}' are NotImplemented.")
            return 'NotImplemented'

        try:
            recommendations = self.get_recommendations_generic(action_type, create_action_prompt)
            if recommendations is not None:
                logger.info(f"Successfully received action recommendations for '{action_type}'.")
                return recommendations

            logger.warning(f"No action recommendations received for '{action_type}'.")
            return None
        except Exception as e:
            logger.exception(f"Error in getting action recommendations for '{action_type}': {e}")
            return None

    def fetch_recommendations(self) -> Optional[list]:
        logger.info("Starting the process to get recommendations.")

        recommendations = self.fetch_cleaning_recommendations()
        if not recommendations:
            logger.warning("No cleaning recommendations found.")
            return
        else:
            logger.info("Cleaning recommendations received. Processing recommendations.")
            self.recommendations_raw = recommendations
            return recommendations

    def process_recommendations(self) -> Optional[dict]:
        try:
            processed_recommendations = self.process_recommendations_string()
            self.recommendations = processed_recommendations
            logger.info("Recommendations processed successfully.")
            return processed_recommendations
        except Exception as e:
            logger.exception(f"Error processing recommendations: {e}")
            return None

    def process_recommendations_string(self) -> dict:
        logger.info("Starting to process recommendations string.")

        try:
            # Convert the string to a dictionary
            recommendations_str = self.recommendations_raw[0]
            recommendations_dict = fix_json_string(recommendations_str, "recommendation")
        except json.JSONDecodeError as e:
            logger.error("JSON processing failed: " + str(e))
            logger.error("Ensure that max_tokens in llm_config is sufficiently large.")
            return {}

        # Process and build the new dictionary
        processed_recommendations = {}
        for rec in recommendations_dict.values():
            if 'function' in rec:
                function_key = rec['function']
                if ' ' in function_key:
                    # TODO: LLM might still send back a space in the function name.
                    # Replace spaces with underscores
                    function_key = function_key.replace(' ', '_')
                recommendation_value = rec['recommendation']

                if function_key in processed_recommendations:
                    processed_recommendations[function_key] += " " + recommendation_value
                    logger.debug(f"Appending recommendation for existing function key: {function_key}")
                else:
                    processed_recommendations[function_key] = recommendation_value
                    logger.debug(f"Adding new function key: {function_key}")
            else:
                logger.warning(f"Function key missing in recommendation: {rec}")

        logger.debug(f"Processed recommendations: {processed_recommendations}")
        logger.info("Finished processing recommendations string.")
        return processed_recommendations

    def compare_recommendations(self) -> (list, list):
        logger.info("Starting to compare recommendations.")

        # Convert the keys of the dictionaries to sets
        keys_dict1 = set(self.recommendations.keys())
        keys_dict2 = set(self.action_types.keys())
        logger.debug(f"Keys in recommendations: {keys_dict1}")
        logger.debug(f"Keys in action types: {keys_dict2}")

        # Find common keys and keys unique to dict1
        common_keys = keys_dict1.intersection(keys_dict2)
        unique_to_dict1 = keys_dict1.difference(keys_dict2)

        # Convert the sets back to lists (optional, depending on your requirement)
        common_keys_list = list(common_keys)
        unique_to_dict1_list = list(unique_to_dict1)
        logger.info(f"Common keys found: {common_keys_list}")
        logger.info(f"Keys unique to recommendations: {unique_to_dict1_list}")
        # TODO: if there are no common keys, break or panic
        # self.actions = common_keys_list
        logger.info("Comparison of recommendations completed.")
        logger.debug(f"Actions determined: {common_keys_list}")
        return common_keys_list, unique_to_dict1_list

    def tune_recommendations(self) -> dict:
        logger.info("Starting to tune recommendations for Retina.")

        processed_action_types, unknown_recommendations = self.compare_recommendations()
        logger.debug(f"Processed action types: {processed_action_types}")
        if unknown_recommendations:
            # TODO: decide what to do with unknown_recommendations
            logger.debug(f"Unknown recommendations: {unknown_recommendations}")

        recommendation_for_retina = dict()
        for action in processed_action_types:
            try:
                logger.debug(f"Processing action: {action}")
                recommendation = self.get_action_recommendations(action)

                # Check if the recommendation is NotImplemented or None
                if recommendation == 'NotImplemented':
                    logger.warning(f"Recommendation for action '{action}' is NotImplemented.")
                elif recommendation is None:
                    logger.warning(f"No recommendation received for action '{action}'.")

                recommendation_for_retina[action] = recommendation

            except Exception as e:
                # Log the exception and optionally, handle it
                logger.error(f"Error occurred while getting recommendation for action '{action}': {e}")
                # Handle the exception as needed, e.g., set a default value or continue
                recommendation_for_retina[action] = None  # or some default value

        self.actions_raw = recommendation_for_retina
        logger.debug(f"Final action recommendations: {recommendation_for_retina}")
        logger.info("Finished tuning recommendations.")
        return recommendation_for_retina

    def process_actions(self) -> Optional[dict]:
        logger.debug("Starting to process actions based on recommendations.")
        recommendation_for_retina = self.tune_recommendations()
        processed_actions = {}

        for action, recommendation in recommendation_for_retina.items():

            if recommendation is not None and recommendation != 'NotImplemented':
                try:
                    recommendation_string = recommendation[0]
                    logger.debug(f"Processing action: {action} with recommendation string: {recommendation_string}")
                    processed_action = process_action_string(action, recommendation_string)
                    if processed_action:
                        processed_actions[action] = processed_action
                        logger.info(f"Action '{action}' processed successfully.")
                except Exception as e:
                    logger.exception(f"Error processing recommendations for action '{action}': {e}")
            else:
                logger.warning(f"Recommendation for action '{action}' is None or NotImplemented.")

        if processed_actions:
            self.actions = processed_actions
            logger.info("All recommendations processed successfully.")
            return processed_actions
        else:
            logger.warning("No valid recommendations were processed.")
            return None

    def run_preprocessing(self):
        """ Run the actions stored in self.actions on the DataFrame. """

        logger.info("Starting to run actions on the DataFrame.")

        if not self.actions:
            logger.warning("No actions to run. Exiting the method.")
            return

        logger.info(f"Reading file for processing: {self.file_processor.new_file_path}")
        df = self.file_processor.read_file(self.file_processor.new_file_path)

        # Iterate over the actions and apply them to the DataFrame
        for action_type, recommendation in self.actions.items():
            try:
                # Get the corresponding function for the action
                action_function = action_functions.get(action_type)
                if action_function:
                    logger.info(f"Executing action: {action_type}")
                    df = action_function(df, recommendation)
                    logger.info(f"Action '{action_type}' executed successfully.")
                else:
                    logger.warning(f"No action function found for '{action_type}'. Skipping.")
            except Exception as e:
                logger.error(f"Error executing action '{action_type}': {e}")
                # Optional: Decide whether to continue or break the loop in case of an error
                # break

        logger.info("All actions have been executed. Writing the processed DataFrame to file.")
        self.file_processor.write_file(df, self.file_processor.processed_file_path)
        logger.info(f"Processed DataFrame written to: {self.file_processor.processed_file_path}")

