# TODO: read PREPROCESSING_ACTION_PROMPTS from config maybe? otherwise the prompt will be updating all the time.

PREPROCESSING_PROMPTS = {
    "general_analysis": "Analyze the following CSV data and suggest general preprocessing steps:\n\n{"
                        "data}\n\nSuggested preprocessing steps:",
    "general_analysis_dict": "Given the CSV data below, please analyze it and provide suggested preprocessing steps "
                             "in the format of a Python dictionary. Format the response with an opening curly bracket "
                             "at the beginning and a closing curly bracket at the end, where each key is a number "
                             "starting from 0 and incrementing by 1 for each step. Ensure each key-value pair is "
                             "separated by a comma. Example: {{'0': 'Step1', '1': 'Step2'}}\n\nCSV Data:\n{"
                             "data}\n\nPreprocessing Steps in Dictionary Format:\n",
    "general_analysis_dict_nested": """Given the CSV data provided below, please conduct a thorough analysis and 
suggest preprocessing steps. These steps should be formatted as a nested Python dictionary. Each key in the outer 
dictionary will represent a preprocessing step, numbered sequentially starting from 0. The corresponding value 
for each key should be another dictionary, containing two keys: 'recommendation' and 'function'.

Under 'recommendation', describe the suggested preprocessing step in detail, specifically mentioning the columns of 
the CSV data to which the step applies. For instance, if a column contains numerical data with outliers, explain how 
handling outliers would improve the data's integrity. Similarly, for categorical data, mention if and why duplicates 
should be removed or if missing values need attention. For clarity, include a brief explanation of why each preprocessing step is recommended for the 
specific columns mentioned. \n
The 'function' key should be paired with one of the following values based on the most suitable action for the 
recommendation: 'remove_missing', 'normalize', 'handle_outliers', or 'remove_duplicates'. If these 
options don't fit a particular recommendation, set the 'function' key to null (without quotes).\n
Your response should be formatted as a JSON object starting with an opening curly bracket and ending with a closing one, with each key-value pair separated by commas.\n
CSV Data:\n
{data}\n
Example output for CSV data:\n
{{
  "0": {{
    "recommendation": "Normalize the 'age' column to scale the data appropriately, as it shows significant variance.",
    "function": "normalize"
  }},
  "1": {{
    "recommendation": "Remove duplicates in the 'user_id' column to ensure data uniqueness.",
    "function": "remove_duplicates"
  }}
}}\n"""
}

PREPROCESSING_ACTION_PROMPTS = {
    "remove_duplicates": """Given the following CSV data, please analyze it and provide recommendations for 
    deduplication. Suggest the most appropriate columns for deduplication ('subset_columns') and a column for sorting 
    ('sort_column') if applicable. Furthermore, determine if the deduplication function needs to be run multiple 
    times with different 'subset_columns'. If so, please also provide the different combinations of 'subset_columns' 
    that should be used in each run, and set 'run_multiple_times' to true. Present your suggestions in the format of a Python dictionary. The dictionary 
    should include keys 'subset_columns' (a list with a single list of two columns names or a list of lists of two columns names if multiple combinations are 
    needed), 'sort_column' (a single column name or null), and 'run_multiple_times' (a boolean value, string starts with lower letter). Return a single dictionary.
    
    Your response should be formatted as a JSON object starting with an opening curly bracket and ending with a closing one, with each key-value pair separated by commas. 
CSV Data:\n
{data}\n
Example output for CSV data:\n
{{
  "subset_columns": [ ['column1', 'column2'], ['column3', 'column4'] ],
  "sort_column": 'date_column', 
  "run_multiple_times": true
}}\n""",
    "remove_missing": "NotImplemented",
    "normalize": "NotImplemented",
    "handle_outliers": "NotImplemented",
}
