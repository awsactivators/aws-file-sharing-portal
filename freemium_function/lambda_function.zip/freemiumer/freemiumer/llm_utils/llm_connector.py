# This module will handle the direct connection to the LLM API. It will be responsible for initializing
# the connection and sending requests to the LLM.


from openai import OpenAI, Completion
from loguru import logger
from freemiumer.utils.config_loader import config
from typing import Optional


class LLMConnector:
    def __init__(self, api_key: str) -> None:
        try:
            # Set the API key
            self.api_key = api_key
            logger.info("LLM Connector initialized successfully with API key.")
        except Exception as e:
            logger.error(f"Error initializing LLM Connector: {e}")
            raise
        self.client = OpenAI(api_key=self.api_key)

    def query(self, prompt: str,
              max_tokens: int = config.get('llm_config')['max_tokens'],
              engine: str = config.get('llm_config')['engine']) -> Optional[Completion]:
        """

        :param prompt:
        :param max_tokens:
        :param engine:
        :return:
        """
        try:
            response: Completion = self.client.completions.create(model=engine,
                                                                  prompt=prompt,
                                                                  max_tokens=max_tokens,
                                                                  temperature=0.7,
                                                                  top_p=1,
                                                                  n=1,
                                                                  stop=None,
                                                                  presence_penalty=0,
                                                                  frequency_penalty=0
                                                                  )
            logger.info("LLM query executed successfully.")
            logger.debug(f"LLM response: {response}")
            return response
        except Exception as e:
            logger.error(f"Error in LLM query: {e}")
            return None

# Completion(id='cmpl-8cA5wb04RFnHP726808L5Y17cVgPW',
#            choices=[CompletionChoice(finish_reason='length',
#                                      index=0,
#                                      logprobs=None,
#                                      text="{\n    '0': {\n        'recommendation': 'Handle outliers in the "
#                                           "'Quantity' column to ensure the integrity of the data.',\n        "
#                                           "'function': 'handle outliers'\n    },\n    '1': {\n        "
#                                           "'recommendation': 'Normalize the 'Price' column to scale the data "
#                                           "appropriately, as it shows significant variance.',\n        'function': "
#                                           "'normalize data'\n    },\n    '2': {\n        'recommendation': 'Remove "
#                                           "duplicates in the 'Supplier' column to ensure data uniqueness.',"
#                                           "\n        'function': 'remove duplicates'\n    },\n    '3': {\n        "
#                                           "'recommendation': '")],
#            created=1704105960,
#            model='text-davinci-003',
#            object='text_completion', system_fingerprint=None,
#            usage=CompletionUsage(completion_tokens=150, prompt_tokens=560, total_tokens=710),
#            warning='This model version is deprecated. Migrate before January 4, 2024 to avoid disruption of service. '
#                    'Learn more https://platform.openai.com/docs/deprecations')
