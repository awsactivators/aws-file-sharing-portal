# This module can contain helper functions that assist in creating prompts
# or processing the LLM's responses.

from loguru import logger
from freemiumer.llm_utils.preprocessing_prompts import PREPROCESSING_PROMPTS, PREPROCESSING_ACTION_PROMPTS
from typing import List, Optional
from openai import Completion


def create_prompt_from_template(data_sample, type_key, template_dict) -> Optional[str]:
    try:
        prompt_template = template_dict.get(type_key)

        # Check if prompt_template is NotImplemented
        if prompt_template is NotImplemented:
            logger.info(f"Prompt template for {type_key} is set to NotImplemented.")
            return NotImplemented

        if prompt_template:
            prompt = prompt_template.format(data=data_sample)
            logger.info(f"Prompt for {type_key} created successfully.")
            logger.debug(f"Prompt: {prompt}")
            return prompt
        else:
            logger.warning(f"Prompt for type '{type_key}' not found.")
            return None
    except Exception as e:
        logger.error(f"Error creating prompt for {type_key}: {e}")
        return None


def create_preprocessing_prompt(data_sample, analysis_type) -> Optional[str]:
    logger.debug(f"Creating preprocessing prompt. Analysis Type: {analysis_type}")
    prompt = create_prompt_from_template(data_sample, analysis_type, PREPROCESSING_PROMPTS)
    return prompt


def create_action_prompt(data_sample, action_type) -> Optional[str]:
    logger.debug(f"Creating action prompt. Action Type: {action_type}")
    prompt = create_prompt_from_template(data_sample, action_type, PREPROCESSING_ACTION_PROMPTS)

    if prompt is NotImplemented:
        logger.info(f"Action prompt for type '{action_type}' is NotImplemented.")
        # Handle NotImplemented as needed, e.g., return it or return None
        return NotImplemented
    return prompt


def process_llm_response(response: Completion) -> Optional[List[str]]:
    """
    response = {"choices": [{"text": "response text here"}]}
    :param response:
    :return:
    """
    try:
        logger.info("Processing LLM response started.")
        # Process the extracted string
        formatted_recommendation = extract_text_from_llm_response(response)
        logger.info("Formatted recommendation successfully.")
        return formatted_recommendation
    except Exception as e:
        logger.error(f"Failed to format recommendation: {e}")
        return None


def extract_text_from_llm_response(response: Completion) -> List[str]:
    """
    Extracts the 'text' field from each choice in the response object.

    :param response: The Completion object returned by the OpenAI API.
    :return: A list of strings, where each string is the 'text' field from a choice in the response.
    """
    # TODO: at the moment we assume length of 1 for this list. Need to implement more robust logic
    logger.info("Extracting text from response.")
    if response and response.choices:
        texts = [choice.text for choice in response.choices]
        if any(text.strip() == '' for text in texts):
            logger.error("Error: One or more extracted texts are empty.")
            raise ValueError("Extracted text contains empty string(s).")
        logger.info(f"Extracted {len(texts)} texts from response.")
        return texts
    else:
        logger.warning("Response is empty or does not contain choices.")
        return []
