import re
import pandas as pd
from pathlib import Path
from datetime import datetime
import uuid
from loguru import logger
from contextlib import contextmanager
import io
from abc import ABC, abstractmethod
from typing import Union
from freemiumer.utils.s3_client import s3_client
from typing import IO, cast


# TODO: remove or hide functionqlity to save the file twice (functionality from initial development0

def parse_file_path(file_path: str):
    if re.match(r's3://', file_path):
        bucket, key = file_path.replace("s3://", "").split("/", 1)
        file_extension = '.' + key.split('.')[-1]
        key_prefix = key.rsplit('/', 1)[0] + '/' if '/' in key else ''
        return {'type': 's3', 'bucket': bucket, 'key': key, 'file_extension': file_extension, 'key_prefix': key_prefix,
                'original': file_path}
    else:
        source_path = Path(file_path)
        file_extension = source_path.suffix
        return {'type': 'local', 'source_path': source_path, 'file_extension': file_extension, 'key_prefix': '',
                'original': source_path}


# Implementing Strategy Pattern is a behavioral design pattern that enables selecting an algorithm's
# implementation at runtime.
class AbstractReader(ABC):
    """Abstract method that reads a file from a given path.
       This method must be implemented by concrete subclasses.
    """

    excel_extensions = {"xls", "xlsx", "xlsm", "xlsb", "odf", "ods", }

    @abstractmethod
    def read_file(self, file_path):
        pass


class AbstractWriter(ABC):
    excel_extensions = {"xls", "xlsx", "xlsm", "xlsb", "odf", "ods", }

    @abstractmethod
    def write_file(self, df, file_path):
        pass


class LocalReader(AbstractReader):
    """Class to read and load numeric data into pandas dataframe."""

    @staticmethod
    def _validate_input(file_path: Union[Path, str]) -> Path:
        # If file_path is a string, convert it to a Path object
        if isinstance(file_path, str):
            return Path(file_path)
        elif not isinstance(file_path, Path):
            error_message = f"Argument file_path should be of Path or str type. Received {type(file_path)}"
            logger.error(error_message)
            raise TypeError(error_message)
        return file_path

    def read_file(self, file_path: Union[Path, str]) -> pd.DataFrame:
        self._validate_input(file_path)
        file_extension = file_path.suffix.lower()

        logger.info(f"Attempting to read file: {file_path} with extension: {file_extension}")
        try:
            if file_extension == ".csv":
                df = pd.read_csv(file_path)
            elif file_extension == ".tsv":
                df = pd.read_csv(file_path, sep="\t")
            elif file_extension.lstrip('.') in self.excel_extensions:
                df = pd.read_excel(file_path)
            else:
                error_message = (f'Unsupported filetype: {file_extension}. Supported extensions: '
                                 f'{list(self.excel_extensions)}')
                logger.error(error_message)
                raise ValueError(error_message)

            logger.info(f"File read successfully: {file_path}")
        except Exception as e:
            logger.exception(f"Error reading file {file_path}: {e}")
            raise

        return df


class LocalWriter(AbstractWriter):
    """Class to write pandas dataframes to various file formats."""

    @staticmethod
    def _validate_input(file_path: Union[Path, str]) -> Path:
        # If file_path is a string, convert it to a Path object
        if isinstance(file_path, str):
            return Path(file_path)
        elif not isinstance(file_path, Path):
            error_message = f"Argument file_path should be of Path or str type. Received {type(file_path)}"
            logger.error(error_message)
            raise TypeError(error_message)
        return file_path

    def write_file(self, df: pd.DataFrame, file_path: Union[Path, str]) -> None:
        file_path = self._validate_input(file_path)
        file_extension = file_path.suffix.lower()

        logger.info(f"Attempting to write DataFrame to file: {file_path} with extension: {file_extension}")
        try:
            if file_extension == ".csv":
                df.to_csv(file_path, index=False)
            elif file_extension == ".tsv":
                df.to_csv(file_path, sep="\t", index=False)
            elif file_extension.lstrip('.') in self.excel_extensions:
                df.to_excel(file_path, index=False)
            else:
                error_message = f'Unsupported filetype for writing: {file_extension}'
                logger.error(error_message)
                raise ValueError(error_message)

            logger.info(f"DataFrame successfully written to file: {file_path}")
        except Exception as e:
            logger.exception(f"Error writing DataFrame to file {file_path}: {e}")
            raise


class FileProcessor:
    def __init__(self,
                 destination_path: Union[Path, str],
                 file_path: str):
        self.reader = None
        self.writer = None
        self.destination_path = destination_path

        self.new_file_path = None
        self.processed_file_path = None
        self._initialize_processors(file_path)
        logger.info(f"FileProcessor initialized with destination: {self.destination_path}")

    def _initialize_processors(self, file_path: str):
        """Initialize the processors based on the file path.
            S3 file paths strictly follow the s3://bucket/key format.
        """
        # Determine if the file path is for S3 or local
        if re.match(r's3://', file_path):
            self.reader = S3Reader()
            self.writer = S3Writer()
        else:
            self.reader = LocalReader()
            self.writer = LocalWriter()
            self.destination_path.mkdir(parents=True, exist_ok=True)

    def read_file(self, file_path: str) -> pd.DataFrame:
        logger.info(f"Reading file: {file_path}")
        try:
            return self.reader.read_file(file_path)
        except Exception as e:
            logger.exception(f"Error reading file {file_path}: {e}")
            raise

    def write_file(self, df: pd.DataFrame, file_path: str) -> None:
        logger.info(f"Writing DataFrame to file: {file_path}")
        try:
            self.writer.write_file(df, file_path)
        except Exception as e:
            logger.exception(f"Error writing DataFrame to file {file_path}: {e}")
            raise

    @contextmanager
    def file_processing_context(self, path_info: dict):
        try:
            # Logging the start of file processing
            logger.info(f"Started file processing for: {path_info['original']}")

            # Construct a unique file name
            random_uuid = uuid.uuid4()
            date_str = datetime.now().strftime("%Y%m%d_%H%M%S")
            new_file_name = f"{random_uuid}_{date_str}{path_info['file_extension']}"
            processed_file_name = f"{random_uuid}_{date_str}_proc{path_info['file_extension']}"

            if path_info['type'] == 's3':
                # Handle S3 path
                new_file_key = path_info['key_prefix'] + new_file_name
                processed_file_key = path_info['key_prefix'] + processed_file_name
                self.new_file_path = f"s3://{path_info['bucket']}/{new_file_key}"
                self.processed_file_path = f"s3://{path_info['bucket']}/{processed_file_key}"
                logger.info(
                    f"S3 paths set for new file: {self.new_file_path} and processed file: {self.processed_file_path}")
            else:
                # Handle local path
                self.new_file_path = self.destination_path / new_file_name
                self.processed_file_path = self.destination_path / processed_file_name
                logger.info(
                    f"Local paths set for new file: {self.new_file_path} and processed file: {self.processed_file_path}")

            # Yielding file paths to the context block
            if path_info['type'] == 's3':
                yield path_info['original'], self.new_file_path, self.processed_file_path
            else:
                yield Path(path_info['original']), self.new_file_path, self.processed_file_path
        except Exception as e:
            # Log any exceptions that occur during file processing
            logger.exception(f"An error occurred during file processing for {path_info['original']}: {e}")
            raise
        finally:
            # Logging the end of file processing
            logger.info(f"Completed file processing for: {path_info['original']}")

    def process_file(self, file_path: str):
        logger.info(f"Starting file processing: {file_path}")
        path_info = parse_file_path(file_path)
        with self.file_processing_context(path_info):
            try:
                # Determine the file extension based on whether it's an S3 path or a local path
                file_extension = path_info['file_extension'].lstrip('.')  # Remove the dot if present

                # Check if the file extension is supported
                if file_extension in self.reader.excel_extensions or file_extension == 'csv' or file_extension == 'tsv':
                    source_path = path_info.get('source_path') or path_info['original']
                    df = self.reader.read_file(source_path)
                    self.writer.write_file(df, self.new_file_path)
                    # write the processed file as a placeholder
                    self.writer.write_file(df, self.processed_file_path)
                    logger.info(f"File successfully processed and written to: {self.new_file_path}")
                else:
                    error_message = f"Unsupported file type: .{file_extension}"
                    logger.error(error_message)
                    raise ValueError(error_message)
            except Exception as e:
                logger.exception(
                    f"Error processing file {source_path if 'source_path' in path_info else file_path}: {e}")
                raise


class S3Reader(AbstractReader):
    """Class to read and load numeric data into pandas dataframe from S3."""

    def __init__(self):
        self.s3 = s3_client

    def read_file(self, file_path: str) -> pd.DataFrame:
        bucket, key = file_path.replace("s3://", "").split("/", 1)
        file_extension = key.split('.')[-1].lower()

        logger.info(f"Attempting to read S3 file: {file_path} with extension: {file_extension}")
        try:
            obj = self.s3.get_object(Bucket=bucket, Key=key)
            if file_extension == 'csv':
                df = pd.read_csv(io.BytesIO(obj['Body'].read()))
            elif file_extension == 'tsv':
                df = pd.read_csv(io.BytesIO(obj['Body'].read()), sep='\t')
            elif file_extension in self.excel_extensions:
                df = pd.read_excel(io.BytesIO(obj['Body'].read()))
            else:
                error_message = (f'Unsupported filetype: {file_extension}. Supported extensions: '
                                 f'{list(self.excel_extensions)}')
                logger.error(error_message)
                raise ValueError(error_message)

            logger.info(f"S3 file read successfully: {file_path}")
        except Exception as e:
            logger.exception(f"Error reading S3 file {file_path}: {e}")
            raise

        return df

    def _validate_input(self, bucket: str, key: str) -> None:
        pass


class S3Writer(AbstractWriter):
    """Class to write pandas dataframes to various file formats in S3."""

    def __init__(self):
        self.s3 = s3_client

    def write_file(self, df: pd.DataFrame, file_path: str) -> None:
        bucket, key = file_path.replace("s3://", "").split("/", 1)
        file_extension = key.split('.')[-1].lower()

        logger.info(f"Attempting to write DataFrame to S3 file: {file_path} with extension: {file_extension}")
        try:
            if file_extension == 'csv':
                buffer = io.StringIO()
                df.to_csv(buffer, index=False)
                self.s3.put_object(Bucket=bucket, Key=key, Body=buffer.getvalue())
            elif file_extension == 'tsv':
                buffer = io.StringIO()
                df.to_csv(buffer, sep='\t', index=False)
                self.s3.put_object(Bucket=bucket, Key=key, Body=buffer.getvalue())
            elif file_extension in self.excel_extensions:
                buffer = io.BytesIO()
                with pd.ExcelWriter(cast(IO[str], buffer), engine='xlsxwriter') as writer:
                    df.to_excel(writer, index=False)
                self.s3.put_object(Bucket=bucket, Key=key, Body=buffer.getvalue())
            else:
                error_message = f'Unsupported filetype for writing: {file_extension}'
                logger.error(error_message)
                raise ValueError(error_message)

            logger.info(f"DataFrame successfully written to S3 file: {file_path}")
        except Exception as e:
            logger.exception(f"Error writing DataFrame to S3 file {file_path}: {e}")
            raise
