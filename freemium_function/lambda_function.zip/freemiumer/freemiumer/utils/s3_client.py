from freemiumer.utils.config_loader import config
import boto3

# Initialize a session
session = boto3.Session(
    aws_access_key_id=config.get('aws')['aws_access_key_id'],
    aws_secret_access_key=config.get('aws')['aws_secret_access_key'],
    region_name=config.get('aws')['region_name']
)

# Use the session to create a shared S3 client
s3_client = session.client('s3')
