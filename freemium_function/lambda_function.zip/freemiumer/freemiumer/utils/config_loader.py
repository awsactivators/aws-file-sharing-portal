import toml
from pathlib import Path
from loguru import logger


class Config:
    """

    Class for reading and accessing configuration data from a TOML file.

    Attributes:
        config (dict): Loaded configuration data from the TOML file.

    """
    def __init__(self):
        try:
            config_path = Path(__file__).parent.parent.parent / 'config.toml'
            logger.debug(f"Loading configuration file: {str(config_path)}")
            with config_path.open() as config_file:
                self.config = toml.load(config_file)
            logger.info("Configuration file loaded successfully.")
        except FileNotFoundError:
            logger.error("config.toml file not found.")
            raise
        except Exception as e:
            logger.exception(f"An error occurred while loading the config file: {e}")
            raise

    def get(self, key):
        """
        :param key: The key used to look up a value in the configuration.
        :return: The value associated with the specified key in the configuration, or None if the key is not found.
        """
        value = self.config.get(key)
        if value is None:
            logger.warning(f"Key '{key}' not found in configuration.")
        return value


config = Config()
