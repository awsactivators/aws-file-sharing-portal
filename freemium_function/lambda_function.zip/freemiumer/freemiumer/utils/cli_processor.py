from freemiumer.data_cleaning.llm_recommendation_processor import LLMRecommendationProcessor
# from freemiumer.data_cleaning.llm_cleaning_recommendation import get_cleaning_recommendations, \
#     get_action_recommendations
from freemiumer.data_cleaning.utils import compare_dataframes
from loguru import logger
from freemiumer.file_upload.read import LocalReader, FileProcessor, LocalWriter


class CLIProcessor:
    def __init__(self, destination, llm_connector, file_path):
        self.llm_connector = llm_connector  # Store the passed LLMConnector instance
        # self.recommendations_raw = None
        self.reader = LocalReader()  # Create a Reader instance
        self.writer = LocalWriter()  # Create a Writer instance
        self.file_processor = FileProcessor(destination, file_path)
        self.recommendation_processor = LLMRecommendationProcessor(llm_connector, self.file_processor)
        self.original_file_path = None
        self.new_file_path = None
        self.processed_file_path = None
        # self.recommendations = {}
        # self.actions = {}

    def read_file_path(self, file_path: str):
        logger.info(f"Starting file processing for: {file_path}")
        self.file_processor.process_file(file_path)
        self.new_file_path = self.file_processor.new_file_path
        self.processed_file_path = self.file_processor.processed_file_path
        logger.info(f"Completed file processing. New file path: {self.new_file_path}")
        return self.new_file_path

    def get_recommendations(self):
        if self.new_file_path:
            logger.info(f"Retrieving cleaning recommendations for file: {self.new_file_path}")
            recommendations = self.recommendation_processor.fetch_recommendations()
            logger.info(f"Completed getting recommendations for file: {self.new_file_path}")
            return recommendations
        else:
            logger.warning("Aborted getting recommendations: No file path provided.")

    def process_recommendations(self):
        """ Process LLM recommendations to extract actionable preprocessing functions.
        Expects 'recommendations' to be a dictionary. """
        logger.info("Starting to process recommendations.")

        recommendations_dict = self.recommendation_processor.process_recommendations()
        if not recommendations_dict:
            logger.warning("No recommendations found to process. The recommendations dictionary is empty. No actions "
                           "to process.")
            return
        processed_actions = self.recommendation_processor.process_actions()

        logger.info("All recommendations have been processed successfully.")
        return processed_actions

    def run_preprocessing(self):
        logger.info("Starting to run preprocessing actions.")
        self.recommendation_processor.run_preprocessing()
        logger.info("All preprocessing actions have been run successfully.")
        logger.info("Comparing the original and processed files.")
        df1 = self.file_processor.read_file(self.new_file_path)
        df2 = self.file_processor.read_file(self.processed_file_path)
        compare_dataframes(df1, df2)
